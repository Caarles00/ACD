/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author carles
 */
@Entity
@Table(name="pokemon")
public class pokemon implements Serializable{
    
    //Atributs
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long IDpoke;
    
    @Column
    private String pokename;
    
    @Column
    private String type;
    
    @OneToOne(cascade=CascadeType.ALL)
    private pokemon luchar;
    
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="IDcoach")
    private coach elcoach;
    
    
    @ManyToMany(cascade=CascadeType.ALL,
                fetch=FetchType.LAZY
    )
    @JoinTable(name="poke-ability",
              joinColumns = {@JoinColumn(name="IDpoke")},
              inverseJoinColumns = {@JoinColumn(name="IDability")}
    )
    private Set<abilities> lesAbilities;
    
    //Constructros
    public pokemon(String pokename, String type, coach elcoach) {
        this.pokename = pokename;
        this.type = type;
        this.elcoach = elcoach;
        this.lesAbilities = new HashSet<>();
    }

    public pokemon() {
        this.lesAbilities = new HashSet<>();
    }
    
    //Getters i setters

    public Long getIDpoke() {
        return IDpoke;
    }

    public void setIDpoke(Long IDpoke) {
        this.IDpoke = IDpoke;
    }

    public String getPokename() {
        return pokename;
    }

    public void setPokename(String pokename) {
        this.pokename = pokename;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public coach getElcoach() {
        return elcoach;
    }

    public void setElcoach(coach elcoach) {
        this.elcoach = elcoach;
    }

    public Set<abilities> getLesAbilities() {
        return lesAbilities;
    }

    public void setLesAbilities(Set<abilities> lesAbilities) {
        this.lesAbilities = lesAbilities;
    }
    
    
    //To StringS
    @Override
    public String toString() {
        return "pokemon{" + "IDpoke=" + IDpoke + ", pokename=" + pokename + ", type=" + type + ", IDcoach=" + elcoach + '}';
    }
    
    public String mostrarAbilities(){
        String res = "";
        for (abilities a : lesAbilities) {
            res += a.getAbiliy_name() + "\n";
        }
        return res;
    }
    
    public void addAbility(abilities a){
        if (!this.lesAbilities.contains(a)) {
            lesAbilities.add(a);
            a.addPokemon(this);
        }
    }
}
